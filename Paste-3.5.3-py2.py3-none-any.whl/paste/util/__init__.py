"""
Package for miscellaneous routines that do not depend on other parts
of Paste
"""
